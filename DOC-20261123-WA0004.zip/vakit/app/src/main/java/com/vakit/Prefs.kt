package com.vakit

import android.content.Context
import java.time.LocalDate

class Prefs(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("vakit", Context.MODE_PRIVATE)

    var targetDate: LocalDate
        get() = LocalDate.parse(p.getString("target", "2028-06-15")!!)
        set(v) = p.edit().putString("target", v.toString()).apply()
    var hour: Int
        get() = p.getInt("hour", 8)
        set(v) = p.edit().putInt("hour", v).apply()
    var minute: Int
        get() = p.getInt("minute", 0)
        set(v) = p.edit().putInt("minute", v).apply()
    var notifEnabled: Boolean
        get() = p.getBoolean("notif", true)
        set(v) = p.edit().putBoolean("notif", v).apply()
    var lastMsgId: Int
        get() = p.getInt("lastMsg", -1)
        set(v) = p.edit().putInt("lastMsg", v).apply()

    fun catEnabled(c: Cat) = p.getBoolean("cat_${c.name}", true)
    fun setCat(c: Cat, on: Boolean) = p.edit().putBoolean("cat_${c.name}", on).apply()

    fun activities(d: LocalDate): Set<Int> =
        (p.getStringSet("act_$d", emptySet()) ?: emptySet()).map { it.toInt() }.toSet()
    fun toggleActivity(d: LocalDate, idx: Int) {
        val cur = activities(d).toMutableSet()
        if (!cur.add(idx)) cur.remove(idx)
        p.edit().putStringSet("act_$d", cur.map { it.toString() }.toSet()).apply()
    }
    private fun active(d: LocalDate) = activities(d).isNotEmpty()

    /** Toplam çalışılan gün sayısı. */
    fun totalDays(): Int = p.all.keys.count { it.startsWith("act_") && (p.getStringSet(it, null)?.isNotEmpty() == true) }

    /** Seri: bugün henüz işaretlenmediyse dünden geriye sayılır; seri cezalandırmaz, sadece gösterir. */
    fun streak(today: LocalDate): Int {
        var d = if (active(today)) today else today.minusDays(1)
        var n = 0
        while (active(d)) { n++; d = d.minusDays(1) }
        return n
    }
}
