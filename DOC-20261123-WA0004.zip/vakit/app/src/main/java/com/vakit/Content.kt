package com.vakit

enum class Cat(val label: String) {
    ZAMAN("Zamanın kıymeti"), TEVEKKUL("Tevekkül"), DISIPLIN("Disiplin"),
    SORUMLULUK("Dünya ve sorumluluk"), HAREKET("Harekete geç"), UMUT("Sabır ve umut")
}

/** Anonim motivasyon cümleleri — ayet/hadis DEĞİLDİR. */
data class Msg(val id: Int, val cat: Cat, val text: String)

val ACTION_LINES = listOf(
    "Şimdi yapılacak tek şey: masana otur, 25 dakikayı başlat.",
    "Telefonu bırak, ilk soruyu aç.",
    "Bugün küçük bir başlangıç yeter. Başla.",
    "Önce kalk, sonra düşün. İlk adımı at.",
    "Bir konu seç, 25 dakika çalış."
)

const val ANCHOR = "Vakit geçiyor. Allah'a güven. Gayret et. Bugününü boşa harcama."

private val raw: List<Pair<Cat, String>> = listOf(
    // A) Zaman
    Cat.ZAMAN to "Zaman senden izin almadan geçiyor.",
    Cat.ZAMAN to "Bugün de Allah'ın sana verdiği ömrün bir parçası.",
    Cat.ZAMAN to "Geçen gün geri gelmez. Bugünü sen yönet.",
    Cat.ZAMAN to "Henüz geç değil. Ama sonsuza kadar vaktin de yok.",
    Cat.ZAMAN to "Bugünün saatleri bir daha yaşanmayacak. Nasıl geçmesini istersin?",
    Cat.ZAMAN to "Takvimdeki gün sayısı azalıyor. Bu bir tehdit değil, bir gerçek.",
    Cat.ZAMAN to "Vakit, harcadığın değil, yatırım yaptığın şeydir.",
    Cat.ZAMAN to "Bugün ertelediğin şey, yarın önüne çıkabilir.",
    Cat.ZAMAN to "Her sabah sana yeni bir gün emanet edilir. Onu nasıl kullanacaksın?",
    Cat.ZAMAN to "Saatler sessiz geçer. Fark ettiğinde günler geçmiş olur.",
    // B) Tevekkül
    Cat.TEVEKKUL to "Allah'a tevekkül et. Ama tevekkül, gayretin yerine geçmez.",
    Cat.TEVEKKUL to "Dua et, çalış, sabret ve sonucu Allah'a bırak.",
    Cat.TEVEKKUL to "Rızkını Allah verir. Ama sorumluluğunu sen taşırsın.",
    Cat.TEVEKKUL to "Sonucu kontrol edemezsin. Gayretini kontrol edebilirsin.",
    Cat.TEVEKKUL to "Tevekkül, elini çekmek değil; elinden geleni yapıp gönlünü rahat bırakmaktır.",
    Cat.TEVEKKUL to "Önce üzerine düşeni yap, sonra huzurla bekle.",
    Cat.TEVEKKUL to "Çalışmadan beklemek tevekkül değildir. Çalışıp güvenmek tevekküldür.",
    Cat.TEVEKKUL to "Allah'a güvenmek, bugün masaya oturmana engel değil; sebep olmalı.",
    Cat.TEVEKKUL to "Sınav sonucu elinde değil, bugünkü çalışman elinde.",
    Cat.TEVEKKUL to "Kaygıyı Allah'a bırak, soruyu sen çöz.",
    // C) Disiplin
    Cat.DISIPLIN to "Başlamak için hazır hissetmeyi bekleme.",
    Cat.DISIPLIN to "Motivasyon çoğu zaman başladıktan sonra gelir.",
    Cat.DISIPLIN to "İstemesen bile 10 dakika başla. Sonrasına sonra karar verirsin.",
    Cat.DISIPLIN to "Kendine verdiğin sözleri ne kadar tutuyorsun?",
    Cat.DISIPLIN to "Disiplin, canın istemediğinde de küçük bir adım atabilmektir.",
    Cat.DISIPLIN to "Mükemmel gün bekleme. Bugünü yeterince iyi bir başlangıçla geç.",
    Cat.DISIPLIN to "Bir saatlik gayret, saatlerce süren pişmanlıktan iyidir.",
    Cat.DISIPLIN to "Büyük hedef, her gün tekrarlanan küçük işlerden oluşur.",
    Cat.DISIPLIN to "Telefonu bir kenara koy. Önce ilk 25 dakika.",
    Cat.DISIPLIN to "Her gün biraz, hiçbir gün hiç olmasından çok daha değerlidir.",
    // D) Dünya ve sorumluluk
    Cat.SORUMLULUK to "Geleceğini düşünmek için bugünü tüketme. Bugün harekete geç.",
    Cat.SORUMLULUK to "Ömrünü nasıl geçirdiğin, sana bırakılmış bir sorumluluk.",
    Cat.SORUMLULUK to "Dünya geçici. Verdiğin emek ve niyet kalır.",
    Cat.SORUMLULUK to "Kendi vaktinin hesabını önce kendine ver.",
    Cat.SORUMLULUK to "Ailenin duası, senin emeğinle anlam kazanır. Üzerine düşeni yap.",
    Cat.SORUMLULUK to "Yeteneğin bir emanet. Onu geliştirmek de sorumluluk.",
    Cat.SORUMLULUK to "Bugün, ileride ‘keşke’ demeyeceğin bir gün olabilir.",
    Cat.SORUMLULUK to "Hayat kısa değil; boşa harcanan kısmı fazla. Bugün onu azalt.",
    // E) Harekete geç
    Cat.HAREKET to "Kalk ve başla.",
    Cat.HAREKET to "Şimdi. Masaya otur.",
    Cat.HAREKET to "Defterini aç. İlk satırı yaz.",
    Cat.HAREKET to "Bahane üretmeyi bırak, bir soru çöz.",
    Cat.HAREKET to "Bugünü boşa harcama. Şimdi başla.",
    Cat.HAREKET to "Düşünmeyi bırak, başla. 25 dakika.",
    Cat.HAREKET to "Telefonu bırak. Ders zamanı.",
    Cat.HAREKET to "Bugünün ilk işi: çalışma masası.",
    // F) Sabır ve umut
    Cat.UMUT to "Allah'ın rahmetinden ümit kesme. Yeniden başla.",
    Cat.UMUT to "Kötü geçen bir gün, her şeyin bittiği anlamına gelmez.",
    Cat.UMUT to "Dün olmadıysa bugün yeniden başlayabilirsin.",
    Cat.UMUT to "Sabır, beklemek değil; yorulmadan devam etmektir.",
    Cat.UMUT to "Aksattığın günler seni tanımlamaz. Bugün ne yaptığın tanımlar.",
    Cat.UMUT to "Yeniden başlamak, hiç başlamamaktan her zaman daha güçlüdür.",
    Cat.UMUT to "Zor günler geçer; verdiğin emek geride kalır.",
    Cat.UMUT to "Kendine karşı sabırlı ol, ama vazgeçme."
)

val MESSAGES: List<Msg> = raw.mapIndexed { i, (c, t) -> Msg(i, c, t) }

/** Ayet/hadis: kaynak belirtilir. Meal metinleri anlam özetidir. */
data class Spiritual(val source: String, val text: String)

val SPIRITUAL = listOf(
    Spiritual("Necm Suresi, 53/39", "İnsan için ancak çalıştığının karşılığı vardır."),
    Spiritual("Talâk Suresi, 65/3", "Kim Allah'a tevekkül ederse, Allah ona yeter."),
    Spiritual("Âl-i İmrân Suresi, 3/159", "Karar verdiğinde artık Allah'a tevekkül et."),
    Spiritual("İnşirâh Suresi, 94/5-6", "Şüphesiz zorlukla beraber bir kolaylık vardır."),
    Spiritual("Zümer Suresi, 39/53", "Allah'ın rahmetinden ümidinizi kesmeyin."),
    Spiritual("Bakara Suresi, 2/286", "Allah hiç kimseye gücünün yeteceğinden fazlasını yüklemez."),
    Spiritual("Ra'd Suresi, 13/11", "Bir kavim kendini değiştirmedikçe Allah onların durumunu değiştirmez."),
    Spiritual("Asr Suresi, 103/1-3", "Asra yemin olsun ki insan gerçekten ziyandadır; ancak iman edip salih ameller işleyenler, birbirlerine hakkı ve sabrı tavsiye edenler hariç."),
    Spiritual("Buhârî, Rikâk 1 (6412)", "Peygamberimiz (s.a.v.): İki nimet vardır ki insanların çoğu onlar konusunda aldanmıştır: sağlık ve boş vakit."),
    Spiritual("Müslim, Kader 34 (2664)", "Peygamberimiz (s.a.v.): Sana fayda verecek şeye hırs göster, Allah'tan yardım dile ve acze düşme.")
)
