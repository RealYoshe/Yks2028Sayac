package com.vakit

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

object Notifier {
    private const val CHANNEL = "daily"
    private const val WORK = "daily_work"

    /** Hedef tarihe kalan gün (bugün dahil değil). */
    fun daysLeft(target: LocalDate) = ChronoUnit.DAYS.between(LocalDate.now(), target)

    /** Mesajı seç: açık kategorilerden, bir önceki mesajı tekrar etmeden. */
    fun pick(prefs: Prefs): Msg {
        val pool = MESSAGES.filter { prefs.catEnabled(it.cat) }.ifEmpty { MESSAGES }
        val choices = pool.filter { it.id != prefs.lastMsgId }.ifEmpty { pool }
        val m = choices.random()
        prefs.lastMsgId = m.id
        return m
    }

    fun schedule(ctx: Context) {
        val prefs = Prefs(ctx)
        val wm = WorkManager.getInstance(ctx)
        if (!prefs.notifEnabled) { wm.cancelUniqueWork(WORK); return }
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(prefs.hour, prefs.minute)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = OneTimeWorkRequestBuilder<DailyWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS).build()
        wm.enqueueUniqueWork(WORK, ExistingWorkPolicy.REPLACE, req)
    }

    fun canNotify(ctx: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun show(ctx: Context) {
        if (!canNotify(ctx)) return
        val prefs = Prefs(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Günlük hatırlatma", NotificationManager.IMPORTANCE_HIGH))
        }
        val days = daysLeft(prefs.targetDate)
        val title = if (days >= 0) "2028 YKS'ye $days gün kaldı." else "Hedef tarih geçti — yeni bir hedef belirle."
        val msg = pick(prefs)
        val action = ACTION_LINES.random()
        val big = "$ANCHOR\n${msg.text}\n$action"
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(msg.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        nm.notify(1, n)
    }
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        Notifier.show(applicationContext)
        Notifier.schedule(applicationContext) // ertesi gün için yeniden planla
        return Result.success()
    }
}
