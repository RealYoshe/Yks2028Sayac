package com.vakit

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

private val Bg = Color(0xFF0E0E10)
private val Card = Color(0xFF1A1A1E)
private val Gold = Color(0xFFC9A24B)
private val Dim = Color(0xFFA0A0A8)

private val ACTIVITIES = listOf(
    "Çalışmaya başladım", "25 dakika çalıştım", "Bir deneme çözdüm",
    "Yanlışlarımı analiz ettim", "Bugünü verimli geçirdim"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.schedule(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Gold, onSurface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { Home() }
            }
        }
    }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var version by remember { mutableIntStateOf(0) } // durum değişince yenile
    fun refresh() { version++ }

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(15_000) } }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.canNotify(ctx)) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    @Suppress("UNUSED_EXPRESSION") version
    val today = now.toLocalDate()
    val target = prefs.targetDate
    val days = Notifier.daysLeft(target)
    val remaining = Duration.between(now, target.atStartOfDay())
    val hours = (remaining.toHours() % 24).coerceAtLeast(0)
    val mins = (remaining.toMinutes() % 60).coerceAtLeast(0)
    val dayIdx = today.toEpochDay().toInt()
    val dailyMsg = MESSAGES[Math.floorMod(dayIdx, MESSAGES.size)]
    val spiritual = SPIRITUAL[Math.floorMod(dayIdx, SPIRITUAL.size)]
    val done = prefs.activities(today)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).statusBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("${target.year} YKS", color = Gold, fontSize = 18.sp, letterSpacing = 4.sp)
        Spacer(Modifier.height(8.dp))
        Text(if (days >= 0) "$days" else "0", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Black)
        Text("GÜN", color = Color.White, fontSize = 22.sp, letterSpacing = 8.sp)
        Spacer(Modifier.height(6.dp))
        Text("$hours saat $mins dakika (gün sonuna kadar)", color = Dim, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text("Her gün bir gün daha azalıyor.", color = Dim, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        Text("Bugün yaptıkların, yarın karşına çıkacak.", color = Gold, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))

        Panel(Card) {
            Text("GÜNÜN MESAJI", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text(dailyMsg.text, color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text("Anonim motivasyon sözü · ${dailyMsg.cat.label}", color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        Panel(Card) {
            Text("GÜNÜN AYETİ / HADİSİ", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text(spiritual.text, color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text("Kaynak: ${spiritual.source} (anlam olarak aktarılmıştır)", color = Dim, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))

        StudyTimer(prefs, today) { refresh() }
        Spacer(Modifier.height(12.dp))

        Panel(Card) {
            Text("BUGÜN KENDİN İÇİN NE YAPTIN?", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("Zorunlu değil. Kendine karşı dürüst ol.", color = Dim, fontSize = 12.sp)
            ACTIVITIES.forEachIndexed { i, label ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = i in done, onCheckedChange = { prefs.toggleActivity(today, i); refresh() },
                        colors = CheckboxDefaults.colors(checkedColor = Gold))
                    Text(label, color = Color.White)
                }
            }
            Spacer(Modifier.height(6.dp))
            val streak = prefs.streak(today)
            Text("Çalışma serisi: $streak gün · Toplam çalışılan gün: ${prefs.totalDays()}", color = Color.White, fontSize = 14.sp)
            if (streak == 0) Text("Bugün yeniden başlamak için güzel bir gün.", color = Dim, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        Settings(prefs) { refresh() }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun Panel(bg: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(bg, RoundedCornerShape(14.dp)).padding(16.dp), content = content)
}

@Composable
fun StudyTimer(prefs: Prefs, today: LocalDate, onChange: () -> Unit) {
    var running by remember { mutableStateOf(false) }
    var left by remember { mutableIntStateOf(25 * 60) }
    LaunchedEffect(running) {
        if (running) {
            if (0 !in prefs.activities(today)) prefs.toggleActivity(today, 0)
            onChange()
            while (running && left > 0) { delay(1000); left-- }
            if (running && left == 0) {
                if (1 !in prefs.activities(today)) prefs.toggleActivity(today, 1)
                running = false; left = 25 * 60; onChange()
            }
        }
    }
    Panel(Card) {
        Text("ÇALIŞMAYA BAŞLA", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text("%02d:%02d".format(left / 60, left % 60), color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Text("Uygulama açık kalırken sayar. Başlayınca “Çalışmaya başladım”, 25 dk bitince “25 dakika çalıştım” işaretlenir.", color = Dim, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { if (running) { running = false; left = 25 * 60 } else running = true },
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (running) "Durdur" else "25 dakikalık çalışmayı başlat") }
    }
}

@Composable
fun Settings(prefs: Prefs, onChange: () -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Panel(Card) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("AYARLAR", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
            TextButton(onClick = { open = !open }) { Text(if (open) "Gizle" else "Göster", color = Gold) }
        }
        if (open) {
            val t = prefs.targetDate
            OutlinedButton(onClick = {
                DatePickerDialog(ctx, { _, y, m, d -> prefs.targetDate = LocalDate.of(y, m + 1, d); onChange() }, t.year, t.monthValue - 1, t.dayOfMonth).show()
            }, modifier = Modifier.fillMaxWidth()) { Text("Hedef tarih: ${t.dayOfMonth}.${t.monthValue}.${t.year}", color = Color.White) }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Günlük bildirim", color = Color.White)
                var on by remember { mutableStateOf(prefs.notifEnabled) }
                Switch(checked = on, onCheckedChange = { on = it; prefs.notifEnabled = it; Notifier.schedule(ctx); onChange() })
            }
            OutlinedButton(onClick = {
                TimePickerDialog(ctx, { _, h, m -> prefs.hour = h; prefs.minute = m; Notifier.schedule(ctx); onChange() }, prefs.hour, prefs.minute, true).show()
            }, modifier = Modifier.fillMaxWidth()) { Text("Bildirim saati: %02d:%02d".format(prefs.hour, prefs.minute), color = Color.White) }

            Spacer(Modifier.height(8.dp))
            Text("Bildirim kategorileri", color = Dim, fontSize = 12.sp)
            Cat.values().forEach { c ->
                var on by remember { mutableStateOf(prefs.catEnabled(c)) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.label, color = Color.White, fontSize = 14.sp)
                    Switch(checked = on, onCheckedChange = { on = it; prefs.setCat(c, it) })
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { Notifier.show(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Şimdi test bildirimi gönder", color = Color.White) }
            if (!Notifier.canNotify(ctx)) Text("Bildirim izni kapalı. Telefon ayarlarından VAKİT için bildirimlere izin ver.", color = Gold, fontSize = 12.sp)
        }
    }
}
