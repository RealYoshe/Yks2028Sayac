# VAKİT — 2028

## Derleme (Android Studio)
1. Android Studio'yu (Koala veya üstü) kur, bu klasörü "Open" ile aç. Gradle senkronu otomatik yapılır (internet gerekir).
2. Menü: Build → Build Bundle(s) / APK(s) → Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk — telefona aktarıp kur ("bilinmeyen kaynaklara izin" gerekebilir).
Komut satırı: gradle assembleDebug (Gradle 8.7+, JDK 17, ANDROID_HOME ayarlı).

## Bildirimler nasıl çalışır
- WorkManager, bir sonraki 08:00'e (ayarlanabilir) tek seferlik iş planlar; iş çalışınca bildirimi gösterir ve ertesi gün için kendini yeniden planlar.
- Uygulama kapalıyken ve internetsiz çalışır. Yeniden başlatma, saat/saat dilimi değişimi ve güncellemede BootReceiver yeniden planlar.
- Android 13+ için POST_NOTIFICATIONS izni açılışta istenir. WorkManager "yaklaşık" zamanlar: pil tasarrufu için bildirim birkaç dakika kayabilir. Bazı üreticiler (Xiaomi, Huawei vb.) uygulamayı pil ayarlarından kısıtlayabilir; VAKİT için pil kısıtlamasını kapat.
- Mesaj: 54 çevrimdışı mesaj, 6 kategori; açık kategorilerden seçilir, art arda aynı mesaj gelmez. Başlıktaki gün sayısı her seferinde hedef tarihten hesaplanır.

## İçerik notu
Ayet/hadis kaynakları Content.kt içinde SPIRITUAL listesindedir; metinler anlam özetidir. Yayından önce Diyanet mealiyle karşılaştırmanız önerilir. Diğer cümleler anonim motivasyon sözüdür.
